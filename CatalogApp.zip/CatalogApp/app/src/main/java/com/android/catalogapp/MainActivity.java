package com.android.catalogapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<CompanyRecyclerViewItem> companyItemList = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeCarItemList();

        // Create the recyclerview.
        RecyclerView companyRecyclerView = (RecyclerView)findViewById(R.id.card_view_recycler_list);
        // Create the grid layout manager with 2 columns.
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        // Set layout manager.
        companyRecyclerView.setLayoutManager(gridLayoutManager);

        // Create car recycler view data adapter with car item list.
        CompanyRecyclerViewDataAdapter companyDataAdapter = new CompanyRecyclerViewDataAdapter(companyItemList);
        // Set data adapter.
        companyRecyclerView.setAdapter(companyDataAdapter);

    }

    /* Initialise car items in list. */
    private void initializeCarItemList()
    {
        if(companyItemList == null)
        {
            companyItemList = new ArrayList<CompanyRecyclerViewItem>();
            companyItemList.add(new CompanyRecyclerViewItem("Emami", R.drawable.ic_launcher_background));
            companyItemList.add(new CompanyRecyclerViewItem("Wagh Bakri", R.drawable.ic_launcher_background));
            companyItemList.add(new CompanyRecyclerViewItem("falana", R.drawable.ic_launcher_background));
            companyItemList.add(new CompanyRecyclerViewItem("falana", R.drawable.ic_launcher_background));
            companyItemList.add(new CompanyRecyclerViewItem("falana", R.drawable.ic_launcher_background));
            companyItemList.add(new CompanyRecyclerViewItem("falana", R.drawable.ic_launcher_background));
            companyItemList.add(new CompanyRecyclerViewItem("falana", R.drawable.ic_launcher_background));
            companyItemList.add(new CompanyRecyclerViewItem("falana", R.drawable.ic_launcher_background));
        }
    }
}