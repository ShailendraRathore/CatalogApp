package com.android.catalogapp;

public class CompanyRecyclerViewItem {

    private String companyName;
    private int companyImageId;

    public CompanyRecyclerViewItem(String companyName, int companyImageId) {
        this.companyName = companyName;
        this.companyImageId = companyImageId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getCompanyImageId() {
        return companyImageId;
    }

    public void setCompanyImageId(int companyImageId) {
        this.companyImageId = companyImageId;
    }
}
