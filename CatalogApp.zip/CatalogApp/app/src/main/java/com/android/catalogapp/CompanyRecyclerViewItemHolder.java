package com.android.catalogapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class CompanyRecyclerViewItemHolder extends RecyclerView.ViewHolder {

    private TextView companyTitleText = null;

    private ImageView companyImageView = null;

    public CompanyRecyclerViewItemHolder(View itemView) {
        super(itemView);

        if(itemView != null)
        {
            companyTitleText = (TextView)itemView.findViewById(R.id.card_view_image_title);

            companyImageView = (ImageView)itemView.findViewById(R.id.card_view_image);
        }
    }

    public TextView getCompanyTitleText() {
        return companyTitleText;
    }

    public ImageView getCompanyImageView() {
        return companyImageView;
    }
}
